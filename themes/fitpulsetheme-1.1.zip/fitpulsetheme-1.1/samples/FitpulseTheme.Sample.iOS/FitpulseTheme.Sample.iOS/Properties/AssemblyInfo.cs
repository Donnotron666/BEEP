using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("FitpulseTheme.Sample.iOS")]
[assembly: AssemblyVersion("1.0.*")]

