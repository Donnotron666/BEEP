using MonoTouch.UIKit;

namespace ThemeSample {
	public static class Application {
		static void Main (string[] args)
		{
			UIApplication.Main (args, null, "AppDelegate");
		}
	}
}
