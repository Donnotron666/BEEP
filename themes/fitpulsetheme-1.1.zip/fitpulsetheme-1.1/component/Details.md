To style your app with this theme, call
`FitpulseTheme.Apply` from your AppDelegate's `FinishedLaunching` method:

```csharp
using Xamarin.Themes;
...

public override bool FinishedLaunching (UIApplication app, NSDictionary options)
{
	...
	FitpulseTheme.Apply ();
}
```
 
*Screenshot assembled with [PlaceIt](http://placeit.breezi.com/).*
